//
//  Movie.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation
struct Movie: Codable {

    var title: String
    var posterPath: String?
    var year: String?
    var imdbID: Date?
    var type: String?

  
    enum CodingKeys: String, CodingKey {
        case title = "Title"
        case posterPath = "Poster"
        case year = "Year"
        case imdbID = "imdbID"
        case type = "Type"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        title = try container.decode(.title)
        posterPath = try? container.decode(.posterPath)
        year = try? container.decode(.year)
        imdbID = try? container.decode(.imdbID)
        type = try? container.decode(.type)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(title, forKey: .title)
        try? container.encode(posterPath, forKey: .posterPath)
        try? container.encode(year, forKey: .year)
        try? container.encode(type, forKey: .type)
        try? container.encode(imdbID, forKey: .imdbID)
    }
}

