//
//  MoviesResponse.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation

struct MoviesResponse: Codable {

    private(set) var results: [Movie]?
    private(set) var page: Int?
    private(set) var totalResults: String?
    private(set) var response: String?

    enum CodingKeys: String, CodingKey {
        case results = "Search"
        case page 
        case totalResults = "totalResults"
        case response = "Response"
    }

}
