//
//  TopMoviesRequest.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation

struct TopMoviesRequest: MovieRequest {
    
    var queryOtherItems: [URLQueryItem] {
        return [URLQueryItem(name: "type", value: "movie"),
                URLQueryItem(name: "s", value: self.searchValue),
                URLQueryItem(name: "page", value: String(self.page))]
    }
    var page: Int
    var searchValue: String
    var path: String = ""
    var parameters: [String : Any] {
        return [:]
    }

    init(page: Int, searchValue:String) {
        self.page = page
        self.searchValue = searchValue
    }
}
