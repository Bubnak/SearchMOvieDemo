//
//  LoadingReusableView.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import UIKit

class LoadingReusableView: UICollectionReusableView {

   @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    override func awakeFromNib() {
        super.awakeFromNib()
        activityIndicator.color = UIColor.white
    }
}
