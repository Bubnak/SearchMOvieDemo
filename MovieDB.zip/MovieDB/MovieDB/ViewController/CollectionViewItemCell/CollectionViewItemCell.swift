//
//  CollectionViewItemCell.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import UIKit

class CollectionViewItemCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
