//
//  ViewController.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import UIKit
import Kingfisher

class ViewController: UIViewController,UISearchBarDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchBar: UISearchBar!
    var isSearch : Bool = false
    var searchTxt : String = ""
    
    var loadingView: LoadingReusableView?
    var viewModel = TopRatedViewModel()
    weak var refreshControl: UIRefreshControl?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Search Movie";
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        searchBar.delegate = self
        //Register Item Cell
        let itemCellNib = UINib(nibName: "CollectionViewItemCell", bundle: nil)
        self.collectionView.register(itemCellNib, forCellWithReuseIdentifier: "collectionviewitemcellid")
        setupUI()
    }

     func setupUI() {
     
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = UIColor.red
        refreshControl.attributedTitle =
            NSAttributedString(string: "Pull To Refresh",
                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.red,
                                            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15)])
        refreshControl.addTarget(self, action: #selector(reloadMovies), for: .valueChanged)
        collectionView.insertSubview(refreshControl, at: 0)
        self.refreshControl = refreshControl
    }

     func bindViewModel() {
         viewModel.onChange = viewModelStateChange
     }
    @objc func reloadMovies() {
        viewModel.reloadMovies(searchText: searchTxt)
     }

}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func viewModelStateChange(change: MovieListState.Change) {
        switch change {
        case .none:
            break
        case .fetchStateChanged:
            if !viewModel.state.movies.isEmpty {
                loadingView?.isHidden = true
                break
            }
            loadingView?.isHidden = !viewModel.state.fetching
            break
        case .moviesChanged(let collectionChange):
            switch collectionChange {
            case .reload:
                collectionView.applyCollectionChange(collectionChange,
                                                toSection: PaginationSection.content.rawValue)
            default:
                collectionView.performBatchUpdates({
                collectionView.applyCollectionChange(collectionChange,
                                                toSection: PaginationSection.content.rawValue)
                    }, completion: nil)
            }
            break
        case .error(let movieError):
            switch movieError {
            case .connectionError(_):
                Alert.present(withTitle: "Connection Error", description: "Check your network status and pull to refresh", from: self)
            case .mappingFailed,.reloadFailed:
                Alert.present(withTitle: "No data found", description: "", from: self)
            }
            break
        }
        refreshControl?.endRefreshing()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let section = PaginationSection(rawValue: section) else {
            fatalError("Invalid section! Check `numberOfSections` function.")
        }
        switch section {
        case .content:
            return viewModel.state.movies.count
        case .loading:
            return viewModel.state.page.hasNextPage ? 1 : 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let section = PaginationSection(rawValue: indexPath.section) else {
                   fatalError("Invalid section! Check `numberOfSections` function.")
               }
                          switch section {
               case .content:
                let movieCell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionviewitemcellid", for: indexPath as IndexPath) as! CollectionViewItemCell

                   let movie = viewModel.state.movies[indexPath.row]
                print(movie.imageUrl as Any)
                   KFImageDownloader.showImageFromPosterPath(with: movie.imageUrl, imageView: movieCell.imageView)
                   movieCell.lblTitle.text = movie.title
                   return movieCell
               case .loading:
                   return collectionView.dequeueReusableCell(withReuseIdentifier:"loadingresuableviewid", for: indexPath)
               }
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let section = PaginationSection(rawValue: indexPath.section) else {
            fatalError("Invalid section! Check `numberOfSections` function.")
        }
        if section == .content {
            if viewModel.state.page.hasNextPage,
                indexPath.row == (viewModel.state.movies.count - PaginationSection.offset) {
                viewModel.loadMoreMovies(searchText: searchTxt)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
     
    }
}

extension UICollectionView {
    
    func applyCollectionChange(_ change: CollectionChange, toSection section: Int) {
        func makeIndexPath(using index: Int) -> IndexPath {
            return IndexPath(row: index, section: section)
        }
        
        func makeIndexPaths(using indexSet: IndexSet) -> [IndexPath] {
            return indexSet.map { makeIndexPath(using: $0) }
        }
        
        switch change {
        case .update(let indexes):
            reloadItems(at: makeIndexPaths(using: indexes.toIndexSet()))
        case .insertion(let indexes):
            insertItems(at: makeIndexPaths(using: indexes.toIndexSet()))
        case .deletion(let indexes):
            deleteItems(at: makeIndexPaths(using: indexes.toIndexSet()))
        case .move(let from, let to):
            moveItem(at: makeIndexPath(using: from), to: makeIndexPath(using: to))
        case .reload:
            reloadData()
        }
    }
}

extension ViewController {

    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        searchTxt = searchBar.text ?? ""
        bindViewModel()
        reloadMovies()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }   
}
