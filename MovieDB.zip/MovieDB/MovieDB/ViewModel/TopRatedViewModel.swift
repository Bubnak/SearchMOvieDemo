//
//  TopRatedViewModel.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation

class TopRatedViewModel: MovieViewModel {

    fileprivate(set) var state = MovieListState()
    var onChange: ((MovieListState.Change) -> Void)?
    var nextPage = 0

    func reloadMovies(searchText: String) {
        state.update(page: Page.default)
        fetch(at: state.page.currentPage, searchText: searchText) { [weak self] (movies) in
            guard let strongSelf = self else { return }
            
            strongSelf.onChange?(strongSelf.state.reload(movies: movies))
        }
    }

    func loadMoreMovies(searchText: String) {
        guard state.page.hasNextPage else { return }
        nextPage = state.page.getNextPage()
        fetch(at: state.page.getNextPage(),searchText: searchText) { [weak self] (movies) in
            guard let strongSelf = self else { return }
            strongSelf.onChange?(strongSelf.state.insert(movies: movies))
        }
    }

    func fetch(at page: Int, searchText: String, handler: @escaping ([MovieVM]) -> Void) {
        onChange?(state.setFetching(fetching: true))
        let request = TopMoviesRequest(page: page,searchValue: searchText)
        RequestManager.shared.perform(request) {
            [weak self] (response: Response<MoviesResponse>) in
            guard let strongSelf = self else { return }
            switch response.result {
            case .success(let value):
                guard let movies = value.results,
                      let totalPage = Int(value.totalResults ?? "") else {
                        strongSelf.onChange?(.error(.mappingFailed))
                        return
                }
                var moviesVM: [MovieVM] = []
                for movie in movies{
                    let movieVM = MovieVM(title: movie.title, imageUrl: movie.posterPath)
                    moviesVM.append(movieVM)
                }
                let page = Page(current: self?.nextPage ?? 0, total: totalPage)
                strongSelf.state.update(page: page)
                handler(moviesVM)
            case .failure(let error):
                strongSelf.onChange?(.error(.connectionError(error)))
            }
            strongSelf.onChange?(strongSelf.state.setFetching(fetching: false))
        }
    }
    
}

