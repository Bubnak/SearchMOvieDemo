//
//  Page.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation

struct Page {

    static let `default` = Page(current: 1, total: 1)

    fileprivate(set) var currentPage: Int
    fileprivate(set) var totalPage: Int

    var hasNextPage: Bool {
        return currentPage < totalPage
    }

    init(current: Int, total: Int) {
        currentPage = current
        totalPage = total 
    }

    func getNextPage() -> Int {
        return currentPage + 1
    }

}
