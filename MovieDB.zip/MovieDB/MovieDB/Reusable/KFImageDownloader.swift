//
//  KFImageDownloader.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation
import Kingfisher
class KFImageDownloader {
      static  func showImageFromPosterPath(with posterPath:String? , imageView:UIImageView)  {
                           if let url = self.getImageURL(with: posterPath) {

                             let processor = DownsamplingImageProcessor(size: imageView.image!.size)
                |> RoundCornerImageProcessor(cornerRadius: 0)
            imageView.kf.indicatorType = .activity
            imageView.kf.setImage(
                with: url,
                placeholder: UIImage(named: "noImage"),
                options: [
                    .processor(processor),
                    .scaleFactor(UIScreen.main.scale),
                    .transition(.fade(1)),
                    .cacheOriginalImage
                ], completionHandler:  {
                    result in
                    switch result {
                    case .success(let value):
                        _ = value.source.url?.absoluteString
                    case .failure(let error):
                        print("Job failed: \(error.localizedDescription)")
                    }
                })
                  }
    }
    
    static func getImageURL(with image:String?) -> URL? {
        guard let path = image else {
            return nil
        }
        return  URL(string: path)    }
}
