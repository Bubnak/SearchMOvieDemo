//
//  Response.swift
//  MovieDB
//
//  Created by Bubna K on 1/7/22.
//

import Foundation
import Alamofire

struct Response<Value: Codable> {

    var request: URLRequest?
    var response: HTTPURLResponse?
    var data: Data?
    var result: Result<Value, NetworkError>

}
